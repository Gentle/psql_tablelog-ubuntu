/*
 * table_log () -- log changes to another table
 *
 *
 * see README.table_log for details
 *
 *
 * written by Andreas ' ads' Scherbaum (ads@pgug.de)
 *
 */

/*
#define TABLE_LOG_DEBUG 1
*/
/*
#define TABLE_LOG_DEBUG_QUERY 1
*/
